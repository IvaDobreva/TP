package ballsAndBoxes;

public class Ball {
	private int b;
	
	public Ball(int i) {
		b = i;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
}