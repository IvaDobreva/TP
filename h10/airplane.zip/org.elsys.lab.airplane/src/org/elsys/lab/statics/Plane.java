package org.elsys.lab.statics;

public class Plane {
	private int rows = 27, columns = 6;
	private Human[][] seatsList = new Human[rows][columns];
	
	public void add(Human h){
		for(int r = 0; r<27; r++) {
			for(int c = 0; c < 6; c++) {
				if(seatsList[r][c] != null) {
					seatsList[r][c].setName("name") ;
					seatsList[r][c].setGender("gender") ;
				}
			}
		}
	}
	public void remove(Human h) {
		//remove from seat
	}
	public void clear() {
		//remove all seats
	}
	public int getCapacity() {
		//get number of seats
		return 0;	
	}
	public int getMales() {
		//return male members
	return 0;
	}
	public int getFemales() {
		//return female members
	return 0;
	}

}
