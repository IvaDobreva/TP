package org.elsys.lab.statics;

import java.util.Random;

public class Airplane {
	
	public static void main(String[] args) {
		/*int sum = 0;
		Random generator = new Random();
		while(sum <= 162) {
			int n = generator.nextInt(3)+1;
			if(sum+n >=162) {
				break;
			}
			sum += n;
		}
		System.out.println(sum);*/
		Plane seats = new Plane();
		Human h = new Human();
		seats.add(h);
	
	}

}
