package org.elsys.lab.statics;

import java.util.Random;

public class Human {
	private String name;
	private String[] gender = {"male", "female"};
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setGender(String[] gender) {
		Random generator = new Random();
		int gen = generator.nextInt(2);
		this.gender = gender[gen];
	}
	
	public String getName() {
		return name;
	}
	
	public String getGender() {
		return gender;
	}
}
