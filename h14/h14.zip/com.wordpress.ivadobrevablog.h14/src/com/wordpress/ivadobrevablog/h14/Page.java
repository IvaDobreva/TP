package com.wordpress.ivadobrevablog.h14;

import java.io.*;
import java.net.*;
import java.util.regex.*;

public class Page {
	private URL link;

	public Page(URL l) {
		link = l;
	}

	public void linksGet() throws IOException {
		String regex = "<\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
		BufferedReader in = new BufferedReader(new InputStreamReader(
				link.openStream()));

		String inputLine;
		while ((inputLine = in.readLine()) != null) {
			//if (inputLine.toLowerCase().contains("http")) {
				Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL | Pattern.MULTILINE);
				Matcher m = p.matcher(inputLine.toLowerCase());
				while (m.find()) {
					System.out.println(m.group(1));
				//}
			}
		}
		in.close();
	}
}
